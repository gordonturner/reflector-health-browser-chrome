# @docs

## Todo
[ ] Evaluate usage of jquery
[ ] Configuration for search provider
[ ] Configuration for links

## MVP
[X] Configuration for dark mode
[X] Configuration for install id
[X] Setup Configuration page
[X] Upgrade to Manifest V3
[ ] Publish in the Chrome Web Store

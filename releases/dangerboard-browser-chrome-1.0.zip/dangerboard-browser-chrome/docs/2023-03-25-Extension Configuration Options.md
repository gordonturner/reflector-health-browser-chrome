# 2023-03-25-Extension Configuration Options
- Ref:
https://developer.chrome.com/docs/extensions/mv3/getstarted/
https://developer.chrome.com/docs/extensions/
https://developer.chrome.com/docs/extensions/mv3/options/

https://getbootstrap.com/docs/4.3/components/forms/

## Requirements
User needs to be able to configure their Install Id
User should be able to configure dark mode

